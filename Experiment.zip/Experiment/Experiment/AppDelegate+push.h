//
//  AppDelegate+push.h
//  HYYS
//
//  Created by LC on 2017/3/14.
//  Copyright © 2017年 Lc. All rights reserved.
//

#import "AppDelegate.h"
#import "JPUSHService.h"
#import <AdSupport/AdSupport.h>

#ifdef NSFoundationVersionNumber_iOS_9_x_Max
#import <UserNotifications/UserNotifications.h>

#endif

@interface AppDelegate (push) <JPUSHRegisterDelegate>


- (void)initJPushWithApplication:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions;

@end
