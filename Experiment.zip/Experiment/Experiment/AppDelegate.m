//
//  AppDelegate.m
//  Experiment
//
//  Created by lc-macbook pro on 2017/7/13.
//  Copyright © 2017年 http://www.cnblogs.com/saytome/. All rights reserved.
//

#import "AppDelegate.h"
//#import "AppDelegate+push.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    
    /** 激光推送 **/
//    [self initJPushWithApplication:application didFinishLaunchingWithOptions:launchOptions];
    
    
    

    /** 本地推送 处理消息 **/
    UILocalNotification * localNotificaiton = [launchOptions objectForKey:UIApplicationLaunchOptionsLocalNotificationKey];
    if (localNotificaiton != nil) {
        [self processLocalNotifiction:localNotificaiton];
    }

    
    
    
    /** 原生 本地 远程推送 都要设置下面这段 **/
    {
        application.applicationIconBadgeNumber = 0;
        
        float version = [[[UIDevice currentDevice] systemVersion] floatValue];
        if (version >= 8.0) {
            [[UIApplication sharedApplication] registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeAlert|UIUserNotificationTypeSound|UIUserNotificationTypeBadge categories:nil]];
            
            //注册远程推送通知
            [[UIApplication sharedApplication] registerForRemoteNotifications];
        }else{
            //ios8以下
            [[UIApplication sharedApplication] registerForRemoteNotificationTypes:UIRemoteNotificationTypeAlert|UIRemoteNotificationTypeSound|UIRemoteNotificationTypeBadge];
        }
        
    }

    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    application.applicationIconBadgeNumber = 0;
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}





#pragma mark - 原生本地推送
- (void)processLocalNotifiction:(UILocalNotification*)localNotification
{
    UIAlertView *alterView = [[UIAlertView alloc]initWithTitle:@"lanchApp" message:@"loc" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alterView show];
}

//注册设置提醒后，调用的代理方法
-(void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings
{
    if (notificationSettings.types != UIUserNotificationTypeNone ) {
      
    }
}

//当程序运行在后台，或者程序没有启动，当注册的本地通知到达时。ios会弹框提示，并播放你设置的声音。

//当应用程序运行在前台会调用该代理方法，不会播放声音，不会弹框
- (void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification
{
    //判断应用程序状态来决定是否弹框
    if (application.applicationState == UIApplicationStateActive) {
        UIAlertView *alterView = [[UIAlertView alloc]initWithTitle:@"本地推送" message:notification.alertBody delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
        [alterView show];
    }else if (application.applicationState == UIApplicationStateInactive)
    {
        NSLog(@"UIApplicationStateInactive");
    }else{
        //background
        NSLog(@"UIApplicationStateBackground");
    }
}





#pragma mark - 原生 远程 推送

//当向APNS注册成功时的回调函数
- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    NSLog(@"deviceToken %@",deviceToken);
    //需要把deviceToken上传到服务端，要服务端提供接口
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error{
    NSLog(@"%@",error.localizedDescription);
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    NSLog(@"收到了远程推送通知");
}


@end
