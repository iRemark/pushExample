//
//  ViewController.m
//  Experiment
//
//  Created by lc-macbook pro on 2017/7/13.
//  Copyright © 2017年 http://www.cnblogs.com/saytome/. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)buttonAction:(id)sender {
    
    //注册本地推送,首先生成UILocalNotification对象
    UILocalNotification *localNotifcation = [[UILocalNotification  alloc]init];
    //提示出发的时间
    localNotifcation.fireDate = [NSDate dateWithTimeIntervalSinceNow:1];
    //提示的内容
    localNotifcation.alertBody = @"这是一个测试";
    //制定消息到来时的播放的声音文件，一定要在bundle内，而且声音的持续时间不能超过30s
    localNotifcation.soundName = @"CAT2.wav";
    
    //设置系统角标
    localNotifcation.applicationIconBadgeNumber = 1;
    
    //注册本地通知道系统中，这样系统在指定的时间会出发该通知
    [[UIApplication sharedApplication] scheduleLocalNotification:localNotifcation];
    
}
- (IBAction)buttonAction2:(id)sender {
    //注册本地推送,首先生成UILocalNotification对象
    UILocalNotification *localNotifcation = [[UILocalNotification  alloc]init];
    //提示出发的时间
    localNotifcation.fireDate = [NSDate dateWithTimeIntervalSinceNow:5];
    //提示的内容
    localNotifcation.alertBody = @"这是一个测试";
    //制定消息到来时的播放的声音文件，一定要在bundle内，而且声音的持续时间不能超过30s
    localNotifcation.soundName = @"sound.wav";
    
    //设置系统角标
    localNotifcation.applicationIconBadgeNumber = 1;
    
    //注册本地通知道系统中，这样系统在指定的时间会出发该通知
    [[UIApplication sharedApplication] scheduleLocalNotification:localNotifcation];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
